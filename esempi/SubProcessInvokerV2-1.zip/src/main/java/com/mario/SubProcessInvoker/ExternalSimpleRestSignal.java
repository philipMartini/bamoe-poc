package com.mario.SubProcessInvoker;


import java.net.URI;
import java.lang.Object;

import com.google.common.net.HttpHeaders;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.drools.core.process.instance.WorkItemHandler;
import org.kie.api.runtime.process.WorkItem;
import org.kie.api.runtime.process.WorkItemManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import java.util.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;

public class ExternalSimpleRestSignal implements WorkItemHandler {
    private static final Logger logger = LoggerFactory.getLogger(ExternalSimpleRestSignal.class);

    private String host = "http://localhost:8080/kie-server";
    private String userName = "admin";
    private String password = "passw0rd";
    
    private final static String SERVICE_SEND_MESSAGE_PARENT_TO_CHILD = "%s/services/rest/server/containers/%s/processes/instances/signal/%s";
    private final static String SERVICE_SEND_MESSAGE_CHILD_TO_PARENT = "%s/services/rest/server/containers/%s/processes/instances/%s/signal/%s";
    private final static String SERVICE_GET_CONTAINERS = "%s/services/rest/server/containers?artifactId=%s&status=STARTED";
    private final static String SERVICE_GET_INFO_BY_PROCESS_INSTANCE_ID = "%s/services/rest/server/queries/processes/instances/%s";
    
    public ExternalSimpleRestSignal() {
    }

    @Override
    public void executeWorkItem(WorkItem workItem, WorkItemManager manager) {
        logger.info("SubProcessMessage-ExternalClass Version: 1.0.30");
        logger.info("Sending external signal through custom work item handler");
        logger.info("Parameters:" + workItem.getParameters());
        
        if(workItem.getParameter("Data") instanceof String){
            logger.info("DATA:" + (String)workItem.getParameter("Data"));
        } else {
            logger.info("DATA-NOSTRING:" + workItem.getParameter("Data"));
        }
        
        
        logger.info("SubProcessMessage External Class - START");
        
        
        try {
            HashMap<String,Object> parametersSignal = (HashMap<String,Object>)workItem.getParameter("Data");
            
            logger.info("PARAMETER SIGNAL RECEIVED: " + parametersSignal);
            
            Boolean isStartSignal = (Boolean)parametersSignal.get("isStartSignal");
            String containerId = ""; 
          
            if(isStartSignal){
                String artifactId = (String)parametersSignal.get("artifactId");
                String signalIdSubProcess = (String)parametersSignal.get("signalIdSubProcess");
                Map<String,Object> signalPayload = (HashMap<String,Object>)parametersSignal.get("signalPayload");
                
                containerId = getLastVersionContainerId(artifactId);
                sendSignalParentToChild(containerId,signalIdSubProcess,signalPayload);
            } else {
                String processInstanceId = (String)parametersSignal.get("processInstanceId");
                String signalId = (String)parametersSignal.get("signalId");
                String instanceMessage = (String)parametersSignal.get("instanceMessage");
                Map<String,Object> mapSignalResponse = (HashMap<String,Object>)parametersSignal.get("signalPayload");
                containerId = getContainerByProcessInstanceId(processInstanceId);
                sendSignalChildToParent(containerId,processInstanceId,signalId,instanceMessage,mapSignalResponse);
            }
        }
        catch(Exception ex){
            logger.error(ex.getMessage());
            throw(ex);
        } finally {
            manager.completeWorkItem(workItem.getId(), new HashMap<String, Object>());
        }
    }
    
    public String getLastVersionContainerId(String artifactId)
	{
		String containerId = "";
		String apiUrl = String.format(SERVICE_GET_CONTAINERS,this.host, artifactId);
		logger.info("... GET CONTAINERS: " + apiUrl);
		
		String auth = this.userName + ":" + this.password;
		String encodedAuth = java.util.Base64.getEncoder().encodeToString(auth.getBytes());
		
		java.net.http.HttpClient client = java.net.http.HttpClient.newHttpClient();
		java.net.http.HttpRequest request = java.net.http.HttpRequest.newBuilder()
                .uri(java.net.URI.create(apiUrl))
                .header("Accept", "application/json")
                .header("Authorization", "Basic " + encodedAuth)
                .build();
		
		java.net.http.HttpResponse<String> response = null;
		try {
		    
            logger.info("... CONNECTING AND GET CONTAINERS ");
            response = client.send(request, java.net.http.HttpResponse.BodyHandlers.ofString());
            logger.info("... STATUS CODE: " + response.statusCode());
            if (response.statusCode() >= 200 && response.statusCode()<=299) {
                
                String responseBody = response.body();
                
                logger.info("... GET CONTAINERS RESPONSE: " + responseBody);

                ObjectMapper objectMapper = new com.fasterxml.jackson.databind.ObjectMapper();
                JsonNode jsonResponse = objectMapper.readTree(responseBody);

                String type = jsonResponse.path("type").asText();
                logger.info("RESPONSE TYPE: " + type);
              
                JsonNode kieContainers = jsonResponse.path("result").path("kie-containers").path("kie-container");

                JsonNode latestTimestampContainer = null;
                long latestTimestamp = Long.MIN_VALUE;

                Iterator<JsonNode> elements = kieContainers.elements();
                while (elements.hasNext()) {
                    
                	JsonNode container = elements.next();
                	JsonNode messages = container.path("messages");

                    for (JsonNode message : messages) {
                        long timestamp = message.path("timestamp").path("Date").asLong();

                        if (timestamp > latestTimestamp) {
                            latestTimestamp = timestamp;
                            latestTimestampContainer = container;
                        }
                    }
                }
                
                if (latestTimestampContainer != null) {
                	containerId = latestTimestampContainer.path("container-id").asText();
                	logger.info("LAST VERSION CONTAINER: " + latestTimestampContainer.path("container-id").asText());
                } else {
                	containerId = "";
                    throw new Exception("NO COINTAINER FOUND");
                }
            } else {
                logger.error("ERROR REST INVOKE. STATUS CODE: " + response.statusCode());
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            throw new RuntimeException("Could not execute request with preemptive authentication", e);
        }
		return containerId;
	}
	
	public String getContainerByProcessInstanceId(String processInstanceId) {
		String containerId = "";
		String apiUrl = String.format(SERVICE_GET_INFO_BY_PROCESS_INSTANCE_ID,this.host,processInstanceId);
        logger.info("GetProcessInfo target: " + apiUrl);		
		
		String auth = this.userName + ":" + this.password;
		String encodedAuth = java.util.Base64.getEncoder().encodeToString(auth.getBytes());
		
		java.net.http.HttpClient client = java.net.http.HttpClient.newHttpClient();
		java.net.http.HttpRequest request = java.net.http.HttpRequest.newBuilder()
                .uri(java.net.URI.create(apiUrl))
                .header("Accept", "application/json")
                .header("Authorization", "Basic " + encodedAuth)
                .build();
		
		try {
		    logger.info("... CONNECTING AND GET PROCESS INFO");
            java.net.http.HttpResponse<String> response = client.send(request, java.net.http.HttpResponse.BodyHandlers.ofString());
            
            if (response.statusCode() == 200) {
                String responseBody = response.body();
                logger.info("Response: " + responseBody);
                	
                ObjectMapper objectMapper = new com.fasterxml.jackson.databind.ObjectMapper();
                JsonNode jsonResponse = objectMapper.readTree(responseBody);
                containerId = jsonResponse.path("container-id").asText();
            }
		} catch (Exception e) {
		    logger.error(e.getMessage());
	        throw new RuntimeException("Could not execute request with preemptive authentication", e);
		    
        }
		return containerId;
	}
	
	 public void sendSignalParentToChild(String containerId,String signalIdSubProcess,Map<String,Object> mapSignalPayload){
        try {
            String apiUrl = String.format(SERVICE_SEND_MESSAGE_PARENT_TO_CHILD, this.host, containerId, signalIdSubProcess);
            logger.info("Signal target: " + apiUrl);
    
            RequestConfig config = RequestConfig.custom().setSocketTimeout(60000).setConnectTimeout(60000)
                    .setConnectionRequestTimeout(60000).build();
    
            HttpClientBuilder clientBuilder = HttpClientBuilder.create().setDefaultRequestConfig(config);
            HttpClient httpClient = clientBuilder.build();
            
            ObjectMapper objectMapper = new ObjectMapper();
    
            String signalPayload = objectMapper.writeValueAsString(mapSignalPayload);
            
            RequestBuilder builder = RequestBuilder.post().setEntity(new StringEntity(signalPayload, ContentType.APPLICATION_JSON)).setUri(apiUrl);
            builder.addHeader(HttpHeaders.ACCEPT, "application/json");
            builder.addHeader(HttpHeaders.CONTENT_TYPE, "application/json");
            
            URI requestUri = builder.getUri();
    
            HttpHost targetHost = new HttpHost(requestUri.getHost(), requestUri.getPort(), requestUri.getScheme());
            
            AuthCache authCache = new BasicAuthCache();
            BasicScheme basicAuth = new BasicScheme();
            authCache.put(targetHost, basicAuth);
    
            HttpClientContext clientContext = HttpClientContext.create();
            CredentialsProvider credsProvider = new BasicCredentialsProvider();
            credsProvider.setCredentials(
                    new AuthScope(requestUri.getHost(), requestUri.getPort(), AuthScope.ANY_REALM),
                    new UsernamePasswordCredentials(this.userName, this.password));
            clientContext.setCredentialsProvider(credsProvider);
            clientContext.setAuthCache(authCache);
    
            HttpUriRequest request = builder.build();
        
            logger.info("... CONNECTING AND SENDING SIGNAL ");
            httpClient.execute(targetHost, request, clientContext);
            logger.info("... SIGNAL SENT ");
        } catch (Exception e) {
            logger.error("Unable to send", e);
            throw new RuntimeException("Could not execute request with preemptive authentication ", e);
        }
    }
    
	public void sendSignalChildToParent(String containerId,String processInstanceId,String signalId,String instanceMessage,Map<String,Object> mapSignalResponse){
        try {
            String apiUrl = String.format(SERVICE_SEND_MESSAGE_CHILD_TO_PARENT, host, containerId, processInstanceId, signalId);
            logger.info("Signal target: " + apiUrl);

            RequestConfig config = RequestConfig.custom().setSocketTimeout(60000).setConnectTimeout(60000)
                .setConnectionRequestTimeout(60000).build();

            HttpClientBuilder clientBuilder = HttpClientBuilder.create().setDefaultRequestConfig(config);
    
            HttpClient httpClient = clientBuilder.build();
            
            ObjectMapper objectMapper = new ObjectMapper();
            String signalResponse = objectMapper.writeValueAsString(mapSignalResponse);
                
           
            RequestBuilder builder = RequestBuilder.post().setEntity(new StringEntity(signalResponse, ContentType.APPLICATION_JSON)).setUri(apiUrl);
            builder.addHeader(HttpHeaders.ACCEPT, "application/json");
            builder.addHeader(HttpHeaders.CONTENT_TYPE, "application/json");
            
            URI requestUri = builder.getUri();

            HttpHost targetHost = new HttpHost(requestUri.getHost(), requestUri.getPort(), requestUri.getScheme());
            
            AuthCache authCache = new BasicAuthCache();
            BasicScheme basicAuth = new BasicScheme();
            authCache.put(targetHost, basicAuth);

            HttpClientContext clientContext = HttpClientContext.create();
            CredentialsProvider credsProvider = new BasicCredentialsProvider();
            credsProvider.setCredentials(
                    new AuthScope(requestUri.getHost(), requestUri.getPort(), AuthScope.ANY_REALM),
                    new UsernamePasswordCredentials(this.userName, this.password));
            clientContext.setCredentialsProvider(credsProvider);
            clientContext.setAuthCache(authCache);

            HttpUriRequest request = builder.build();
            
            logger.info("... CONNECTING AND SENDING SIGNAL ");
            httpClient.execute(targetHost, request, clientContext);
            logger.info("... SIGNAL SENT ");
        } catch (Exception e) {
            logger.error("Unable to send", e);
            throw new RuntimeException("Could not execute request with preemptive authentication", e);
        }
    }
	
    @Override
    public void abortWorkItem(WorkItem workItem, WorkItemManager manager) {
        manager.abortWorkItem(workItem.getId());
    }

}